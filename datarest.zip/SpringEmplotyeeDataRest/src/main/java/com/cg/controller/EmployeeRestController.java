package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Employee;
import com.cg.service.EmployeeService;

@RestController
public class EmployeeRestController {
	
	@Autowired
	EmployeeService employeeService;
	@Autowired
	Employee employee;
	@PostMapping("/add/{name}/{address}/{salary}/{designation}")
	public Employee addEmployee(@PathVariable String name , @PathVariable String address ,
			@PathVariable Double salary , @PathVariable String designation) {
		employee.setName(name);
		employee.setAddress(address);
		employee.setSalary(salary);
		employee.setDesignation(designation);
		Employee savedEmp = employeeService.addEmployee(employee);
		
		return savedEmp;
	}
	//post
	//http://localhost:8083/addobject send complete jsom data except id
    @PostMapping(value = "/addobject" , consumes = {MediaType.APPLICATION_JSON_VALUE})
    public Employee addEmpObject(@RequestBody Employee employee) {
    	Employee savedEmp = employeeService.addEmployee(employee);
    	return savedEmp;
    }
   
	@GetMapping("/viewAll")
	public List<Employee> viewAll(){
		return employeeService.getEmployees();
	}
	 //GET
    //HTTP://localhost:8083/viewaddress?address = bangalore
	@GetMapping("/viewaddress")
	
	public List<Employee> viewAddress(@RequestParam String address){
		return employeeService.getEmployeesByAddress(address);
	}
	
	//GET
		//http://localhost:8083/viewaddress/bangalore
	
	@GetMapping("/viewaddress/{address}")
	public List<Employee> viewAddressPath(@PathVariable String address){
		return employeeService.getEmployeesByAddress(address);
	}
	
	
	@GetMapping("viewDesignation")
	public List<Employee> viewDesignation(@RequestParam String designation){
		return employeeService.getEmployeesByDesignation(designation);
	}
	
	//GET
		//http://localhost:8083/viewaddress/bangalore
	
	@GetMapping("/viewDesignation/{designation}")
	public List<Employee> viewDesignationPath(@PathVariable String designation){
		return employeeService.getEmployeesByDesignation(designation);
	}
	

	@DeleteMapping("/deleteById/{empId}")
	public String deleteById(@PathVariable Integer empId) {
		String name =  employeeService.findById(empId).getName();
	     employeeService.deleteById(empId);
	     return empId + "." + name;
	}
	

	@DeleteMapping("deleteAll")
	public void deleteById() {
	     employeeService.deleteAll();
	}
	
	@GetMapping("/findbyid/{empId}")
	public Employee findById(@PathVariable Integer empId) {
		return employeeService.findById(empId);
	}
	
	//get
	//http://localhost:8083/salaryrange/1000/60000
	@GetMapping("/salaryrange/{salary1}/{salary2}")
	public List<Employee> salaryRange(@PathVariable Double salary1 , @PathVariable Double salary2){
		return employeeService.salaryRange(salary1, salary2);
	}
	
    @GetMapping("/salaryrange")
	public List<Employee> salaryRangeParam(@RequestParam Double salary1 , @RequestParam Double salary2){
		return employeeService.salaryRange(salary1 , salary2);
	}
    
    @PutMapping(value = "/updateobject" , consumes = {MediaType.APPLICATION_JSON_VALUE})
    public Employee updateEmpObject(@RequestBody Employee employee) {
    	Employee updatedEmp = employeeService.updateEmployee(employee);
    	return updatedEmp;
    }
	/*
	 * @ResponseStatus(value = HttpStatus.NOT_FOUND , reason =
	 * "Invalid Request -Employee id not present")
	 * 
	 * @ExceptionHandler({Exception.class}) public void handleException() {
	 * 
	 * }
	 */
}

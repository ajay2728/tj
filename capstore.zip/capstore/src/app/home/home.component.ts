import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
url:string="assets/logo1.png";
imageSrc :string;
  constructor(private authSerice:AuthService) { }

  ngOnInit() {
    this.imageSrc="/assets/images/logo1.png";
  }

  logout() {
    this.authSerice.logout()
  }
}

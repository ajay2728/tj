import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule, FormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { LoginComponent } from './comps/login/login.component';
import { LoginService } from './services/login.service';
import { CustomerComponent } from './comps/signups/customer/customer.component';
import { SignupComponent } from './comps/signup/signup.component';
import { AuthGuard } from './auth.guard';
import { ShowCartComponent } from './comps/show-cart/show-cart.component';
import { ShowOrdersComponent } from './comps/show-orders/show-orders.component';
import { WishlistComponent } from './comps/wishlist/wishlist.component';
import { SignupService } from './services/signup.service';
import { MerchantComponent } from './comps/signups/merchant/merchant.component';
import { ConfirmOrderComponent } from './comps/confirm-order/confirm-order.component';
import { ProfileComponent } from './comps/profile/profile.component';
import { AddproductComponent } from './comps/addproduct/addproduct.component';
import { AdminshowproductComponent } from './comps/adminshowproduct/adminshowproduct.component';
import { ChangepasswordComponent } from './comps/changepassword/changepassword.component';
import { GeneratecouponsComponent } from './comps/generatecoupons/generatecoupons.component';
import { MerchantchangepasswordComponent } from './comps/merchantchangepassword/merchantchangepassword.component';
import { MerchantprofileComponent } from './comps/merchantprofile/merchantprofile.component';
import { MerchantshowproductComponent } from './comps/merchantshowproduct/merchantshowproduct.component';
import { ShowcustomerComponent } from './comps/showcustomer/showcustomer.component';
import { ShowmerchantComponent } from './comps/showmerchant/showmerchant.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AdminComponent,
    LoginComponent,
    CustomerComponent,
    SignupComponent,
    ShowCartComponent,
    ShowOrdersComponent,
    WishlistComponent,
    MerchantComponent,
    ConfirmOrderComponent,
    ProfileComponent,
    AddproductComponent,
    AdminshowproductComponent,
    ChangepasswordComponent,
    GeneratecouponsComponent,
    MerchantprofileComponent,
    MerchantchangepasswordComponent,
    MerchantshowproductComponent,
    ShowcustomerComponent,
    ShowmerchantComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [LoginService, SignupService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }

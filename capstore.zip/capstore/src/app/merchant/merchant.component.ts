import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css']
})
export class MerchantComponent implements OnInit {

  url:string="assets/logo1.png";
  imageSrc :string;
    constructor() { }
  
    ngOnInit() {
      this.imageSrc="/assets/images/logo1.png";
    }
  
}

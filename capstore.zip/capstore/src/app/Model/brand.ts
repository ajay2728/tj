import { Inventory } from './inventory';

export class Brand {
     brandId:Number;
  brandName:String;
    inventory:Inventory[]; 
}


import { Inventory } from './inventory';
import { InvoiceProduct } from './invoice-product';

export class Discount {
     
     discountId:number;
     inventory:Inventory;
     promoAmount:number;
     discountPercent:number;
     issueDate:String;
     expiryDate:String;
     promoName:String;
     invoiceProduct:InvoiceProduct; 
 

}

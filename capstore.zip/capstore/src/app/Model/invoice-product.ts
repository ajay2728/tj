import { Discount } from './discount';
import { Inventory } from './inventory';
import { GenerateInvoice } from './generate-invoice';

export class InvoiceProduct {
     invoicepId:number;
     inventory:Inventory[];
	 generateInvoice:GenerateInvoice;
	 discount:Discount;
}

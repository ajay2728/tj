import { Brand } from './brand';
import { Merchant } from './merchant';
import { ManagingCart } from './managing-cart';
import { FeedBack } from './feed-back';
import { WishList } from './wish-list';
import { Category } from './category';
import { Discount } from './discount';
import { Coupons } from './coupons';
import { InvoiceProduct } from './invoice-product';

export class Inventory {
     productId:number;
	
	 productName:String;
	
	 description:String;
	
	 brand:Brand;
	
	 merchant:Merchant;
	
	 noOfViews:number;
	
	 category:Category;
	
	 dateOfInclusion:String;
	
	 price:number;
	
	/*@OneToMany(targetEntity=ProductImages.class, mappedBy="inventory")
	private List<ProductImages> uploadimage;*/
	
	 quantity:number;
	
	 expiryDate:String;
	
	 managingCart:ManagingCart;
	
	 discount:Discount;

	 coupon:Coupons;
	
	 feedback:FeedBack[];
	
	 wishList:WishList[];
	
	 invoiceProduct:InvoiceProduct;
}

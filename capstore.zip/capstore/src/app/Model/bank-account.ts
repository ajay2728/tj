import { Customer } from './customer';
import { RefundMoney } from './refund-money';

export class BankAccount {
     bankAccountId:number;
	 customer:Customer;
	 accountNumber:number;
	 cardNumber:number;
	 balance:number;
	 cvvNumber:number;
	 refundMoney:RefundMoney;
}

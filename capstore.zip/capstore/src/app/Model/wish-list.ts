import { Customer } from './customer';
import { Inventory } from './inventory';

export class WishList {
     wishId:Number;
    customer:Customer;
    inventory:Inventory; 
}

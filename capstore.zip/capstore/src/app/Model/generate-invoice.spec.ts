import { GenerateInvoice } from './generate-invoice';

describe('GenerateInvoice', () => {
  it('should create an instance', () => {
    expect(new GenerateInvoice()).toBeTruthy();
  });
});

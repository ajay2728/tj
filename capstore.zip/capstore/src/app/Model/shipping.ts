import { Customer } from './customer';
import { Address } from './address';
import { Order } from './order';

export class Shipping {
     shippingId:Number;
    customer:Customer;
     shippingAddress:Address;
    order:Order; 
}

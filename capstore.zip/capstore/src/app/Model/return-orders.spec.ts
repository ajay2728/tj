import { ReturnOrders } from './return-orders';

describe('ReturnOrders', () => {
  it('should create an instance', () => {
    expect(new ReturnOrders()).toBeTruthy();
  });
});

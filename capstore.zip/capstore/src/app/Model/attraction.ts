export class Attraction {
     attractionId:number;
	 attractionName:String;
	 attractionUrl:String;
	 status:String;
	 description:String;
}

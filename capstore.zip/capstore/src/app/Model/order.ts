import { Customer } from './customer';
import { ManagingCart } from './managing-cart';
import { Shipping } from './shipping';
import { Transaction } from './transaction';
import { ReturnOrders } from './return-orders';
import { GenerateInvoice } from './generate-invoice';

export class Order {
     orderId:number;
	 customer:Customer;
	 managingCart:ManagingCart[];
	 orderDate:String;
	 deliveredDate:String;
	 shipping:Shipping;
	 deliveryStatus:String;
	 transaction:Transaction;
	 returnOrder:ReturnOrders; 
	 generateInvoice:GenerateInvoice;
}

import { ManagingCart } from './managing-cart';

describe('ManagingCart', () => {
  it('should create an instance', () => {
    expect(new ManagingCart()).toBeTruthy();
  });
});

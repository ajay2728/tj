import { Address } from './address';
import { FeedBack } from './feed-back';
import { Inventory } from './inventory';

export class Merchant {
     merchantId:String;
	 merchantName:String;
	 companyName:String;
	 phoneNo:String;
	 emailId:String;
	 password:String;
	 isCertified:String;
	 isActive:String;
	 lastLogin:String; 
	 status:String; 
     address:Address[];
	 inventory:Inventory[];
	 feedback:FeedBack[];

}

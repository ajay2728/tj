import { Coupons } from './coupons';

describe('Coupons', () => {
  it('should create an instance', () => {
    expect(new Coupons()).toBeTruthy();
  });
});

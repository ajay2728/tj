import { Customer } from './customer';
import { Shipping } from './shipping';
import { Merchant } from './merchant';

export class Address {
     addressId:number;
	 customer:Customer;
	 merchant:Merchant;
	 streetNumber:number;
	 city:String;
	 state:String;
	 country:String;
	 zipcode:number; 
	 shipping:Shipping[];		
}

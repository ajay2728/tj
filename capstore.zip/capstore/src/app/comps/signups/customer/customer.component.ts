import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/Model/customer';
import { Router } from '@angular/router';
import { SignupService } from 'src/app/services/signup.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customerData:Customer={"customerId":0,"customerName":'',"phoneNumber":'',"emailId":'',"dateOfBirth":'', 
  "password":'', "address":null, "lastLogin":'', "isActive":'', "shipping":null, "bank":null, 
  "managingCart":null, "order":null,"feedBack":null, "returnOrders":null, "wishList":null }
  constructor(private signupService:SignupService, private router:Router) { }

  ngOnInit() {
  }

  onSubmit(){
    this.signupService.customerSignup(this.customerData).subscribe((data)=>{
      this.router.navigate(['home']);
    });
  }

}

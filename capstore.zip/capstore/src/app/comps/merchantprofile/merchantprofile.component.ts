import { Component, OnInit } from '@angular/core';
import { Merchant } from '../../Model/merchant';
import { MerchantService } from '../../services/merchant.service';
import { Router, ActivatedRoute } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-merchantprofile',
  templateUrl: './merchantprofile.component.html',
  styleUrls: ['./merchantprofile.component.css']
})
export class MerchantprofileComponent implements OnInit {
  id:string;
  oldPassword:string;
  newPassword:string;
  confirmPassword:string;
  changePasswordForm;
  merchantData:Merchant={"merchantId":"","merchantName":'',"emailId":'',"phoneNo":'',"companyName":'',"password":''
,"isCertified":"","isActive":"","status":"","lastLogin":"","address":[],"inventory":[],"feedback":[]}; 
  constructor(private merchantService:MerchantService, private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
   this.id = localStorage.getItem('token');
  //othis.id = "krishnaveni16@gmail.com";
     console.log(this.id);
           
        console.log(this.merchantData);
        this.merchantService.getMerchant(this.id).subscribe(
          (data)=>
          {
          this.merchantData=data;
          });
   
          
  }

}

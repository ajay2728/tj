import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowmerchantComponent } from './showmerchant.component';

describe('ShowmerchantComponent', () => {
  let component: ShowmerchantComponent;
  let fixture: ComponentFixture<ShowmerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowmerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowmerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

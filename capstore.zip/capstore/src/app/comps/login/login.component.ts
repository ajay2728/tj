import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import { Customer } from 'src/app/Model/customer';
import { Admin } from 'src/app/Model/admin';
import { Merchant } from 'src/app/Model/merchant';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  id:string
  password:string
  role:string
  status:string
  customer:Customer;
  admin:Admin;
  merchant:Merchant;

  constructor(private loginService:LoginService, private router:Router) { }

  ngOnInit() {
  }

  onSubmit() {
    console.log("login button")
    if(this.role=="Admin") {
    this.loginService.adminLogin(this.id).subscribe((data:Admin)=>{
      this.admin=data;
    if(this.admin==null){
      console.log("admin login null object");
      this.status = "No such user with this user id exits"
    }
    else if(this.admin.password==this.password) {
      localStorage.setItem('isLoggedIn', "true");
      localStorage.setItem('token', this.id);
      this.router.navigate(['admin']);
    }
    else {
      console.log("admin login wrong password");
      this.status = "Invalid password";
    }
  });
    }
    else if(this.role=="Merchant") {
      this.loginService.merchantLogin(this.id).subscribe((data:Merchant)=>{
        this.merchant=data;
      
      if(this.merchant==null){
        this.status = "No such user with this user id exits"
      }
      else if(this.merchant.password==this.password) {
        localStorage.setItem('isLoggedIn', "true");
        localStorage.setItem('token', this.id);
        this.router.navigate(['merchant']);
      }
      else {
        this.status = "Invalid password";
      }
    });
    }
    else {
      console.log(this.role);
      this.loginService.customerLogin(this.id).subscribe((data:Customer)=>{
        this.customer=data;
        console.log(this.customer.password)
      
     
      if(this.customer==null){

        this.status = "No such user with this user id exits"
      }
      else if(this.customer.password==this.password) {
        localStorage.setItem('isLoggedIn', "true");
        localStorage.setItem('token', this.id);
        this.router.navigate(['home']);
      }
      else {
        this.status = "Invalid password";
      }
    });
    }


  }

}

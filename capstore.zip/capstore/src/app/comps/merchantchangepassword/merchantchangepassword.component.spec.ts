import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantchangepasswordComponent } from './merchantchangepassword.component';

describe('MerchantchangepasswordComponent', () => {
  let component: MerchantchangepasswordComponent;
  let fixture: ComponentFixture<MerchantchangepasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantchangepasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantchangepasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

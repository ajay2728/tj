import { Component, OnInit } from '@angular/core';
import { WishList } from 'src/app/Model/wish-list';
import { CustomerService } from 'src/app/services/customer.service';
import { Inventory } from 'src/app/Model/inventory';
import { Brand } from 'src/app/Model/brand';
import { Category } from 'src/app/Model/category';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  wlist:WishList={customer:null,wishId:null,inventory:null};
  branddata:Brand={"brandId":0,"brandName":"","inventory":null};
  categorydata:Category={"categoryId":0,"categoryName":'',"dis":null,"inventory":null};
  inventory1:Inventory={"brand":null,"category":null,"coupon":null,"dateOfInclusion":null,
    "description":null,"discount":null,"expiryDate":null,"feedback":null,"invoiceProduct":null,"managingCart":null,"merchant":null,
  "noOfViews":null,"price":0,"productId":null,"productName":'',"quantity":0,"wishList":null};
  

constructor(private customerservice:CustomerService) { }

  ngOnInit() {
    this.inventory1.brand=this.branddata;
    this.inventory1.category=this.categorydata
    this.wlist.inventory=this.inventory1;
    this.customerservice.getWishlist().subscribe((data:WishList)=>{this.wlist=data
    
  });
  }
}

//   deleteWishlist(wlist:WishList)
// {
//   console.log("Delete");
//   this.customerservice.deleteWishlist(wlist).subscribe((data)=>{
//     this.wlist=this.wlist.filter(wishlist=>wishlist!==wlist);
//   });
// }


  


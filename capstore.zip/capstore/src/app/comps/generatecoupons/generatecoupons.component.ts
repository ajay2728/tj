import { Component, OnInit } from '@angular/core';
import { Coupons } from '../../Model/coupons';
import { Category } from '../../Model/category';
import { FormGroup } from '../../../../node_modules/@angular/forms';
import { AdminService } from '../../services/admin.service';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-generatecoupons',
  templateUrl: './generatecoupons.component.html',
  styleUrls: ['./generatecoupons.component.css']
})
export class GeneratecouponsComponent implements OnInit {
 couponData:Coupons={couponCode:'',couponAmount:0,issueDate:'',expiryDate:'',couponDescription:'',
couponId:null,generateInvoice:null,inventory:null};
categoryData:Category={categoryId:0,categoryName:'',dis:null,inventory:null} 

custForm:FormGroup;
  constructor(private adminService:AdminService,private router:Router) { }
 createcouponurl :string='/ admin/createcoupon'
  ngOnInit() {
   
  }

  onSubmit(){
    this.categoryData.categoryName=this.couponData.couponDescription;
    this.couponData.couponDescription=null;
    console.log(this.categoryData.categoryName);
  
    this.adminService.addCoupons(this.couponData,this.categoryData).subscribe(
      (data)=>{this.router.navigate(['generatecoupons']);
    });
  }
}

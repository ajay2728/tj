import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminshowproductComponent } from './adminshowproduct.component';

describe('AdminshowproductComponent', () => {
  let component: AdminshowproductComponent;
  let fixture: ComponentFixture<AdminshowproductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminshowproductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminshowproductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

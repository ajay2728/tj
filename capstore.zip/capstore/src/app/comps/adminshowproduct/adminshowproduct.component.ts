import { Component, OnInit } from '@angular/core';
import { Inventory } from '../../Model/inventory';
import { AdminService } from '../../services/admin.service';



@Component({
  selector: 'app-adminshowproduct',
  templateUrl: './adminshowproduct.component.html',
  styleUrls: ['./adminshowproduct.component.css']
})
export class AdminshowproductComponent implements OnInit {
  product:Inventory[];
  constructor(private adminservice:AdminService) { }

  ngOnInit() {
    this.adminservice.getProduct().subscribe((data:Inventory[])=>{this.product=data
      console.log(this.product+""+this.adminservice.getProduct.length)});
    }
    deleteProduct(product:Inventory){
      console.log("Delete");
      this.adminservice.deleteProduct(product).subscribe((data)=>{this.product=this.product.filter(p=>p!==product);
      });

  }
  }



import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Customer } from '../Model/customer';
import { Admin } from '../Model/admin';
import { Merchant } from '../Model/merchant';


const httpOptions = {
  headers:new HttpHeaders({'Content-Type':'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  url:string ='/admin/loginadmin';
  url1:string = '/merchant/loginmerchant';
  url2:String = '/customer/logincustomer';
  constructor(private http:HttpClient) { }
  public adminLogin(id:String) {
      return this.http.get<Admin>(this.url+"/"+id);
  }
  public merchantLogin(id:String) {
      return this.http.get<Merchant>(this.url1+"/"+id);
  }
  public customerLogin(id:String) {
    return this.http.get<Customer>(this.url2+"/"+id);
  }
      
  }


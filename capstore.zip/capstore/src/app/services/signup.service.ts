import { Injectable } from '@angular/core';
import { Customer } from '../Model/customer';
import { HttpClient } from '@angular/common/http';
import { Merchant } from '../Model/merchant';

@Injectable({
  providedIn: 'root'
})
export class SignupService {

  constructor(private http:HttpClient) { }

  url:string="/customer/addcustomer";
  merchantSignupUrl:string="/merchant/addmerchant";
  id:number=1;

  public customerSignup(customer:Customer) {
    return this.http.post(this.url,customer);
  }

  public merchantSignup(merchant:Merchant) {
    return this.http.post(this.merchantSignupUrl,merchant);
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Merchant } from '../Model/merchant';
import { Coupons } from '../Model/coupons';
import { Customer } from '../Model/customer';
import { Category } from '../Model/category';
import { Inventory } from '../Model/inventory';


@Injectable({
  providedIn: 'root'
})
export class AdminService {
showmerchantsurl:string="/admin/showmerchants";
couponurl:string="/admin/createcoupon";
 showcustomersurl:string="/admin/showcustomers";
 showproductsurl:string="/admin/showproducts";
  constructor(private http:HttpClient) { }
  showMerchants()
  {
      return this.http.get<Merchant[]>(this.showmerchantsurl);
  }
  deleteMerchant(merchant:Merchant)
  {
    return this.http.delete<Merchant[]>(this.showmerchantsurl+"/"+merchant.merchantId);
  }
  approve(merchant:Merchant)
  {
    return this.http.put(this.showmerchantsurl+"/"+merchant.merchantId,merchant);
  }
  showCustomers()
  {
    return this.http.get<Customer[]>(this.showcustomersurl);
  }

  addCoupons(coupons:Coupons,category:Category){
   
    
    return this.http.post(this.couponurl+"/"+category.categoryName,coupons);
  }
  getProduct(){
    return this.http.get<Inventory[]>(this.showproductsurl);
}
 deleteProduct(product:Inventory){
 return this.http.delete<Inventory[]>(this.showproductsurl+"/"+product.productId);
}
getById(id:string){
  return this.http.get<Inventory[]>(this.showproductsurl+"/"+id);
}
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './comps/login/login.component';
import { CustomerComponent } from './comps/signups/customer/customer.component';
import { SignupComponent } from './comps/signup/signup.component';
import { ShowOrdersComponent } from './comps/show-orders/show-orders.component';
import { AuthGuard } from './auth.guard';
import { ShowCartComponent } from './comps/show-cart/show-cart.component';
import { MerchantComponent } from './comps/signups/merchant/merchant.component';
import { ConfirmOrderComponent } from './comps/confirm-order/confirm-order.component';
import { WishlistComponent } from './comps/wishlist/wishlist.component';
import { ProfileComponent } from './comps/profile/profile.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'login', component:LoginComponent},
  {path:'signup', component:SignupComponent},
  {path:'customersignup', component:CustomerComponent},
  {path:'merchantsignup', component:MerchantComponent},
  {path:'showorders', component:ShowOrdersComponent, canActivate:[AuthGuard]},
  {path:'showcart', component:ShowCartComponent, canActivate:[AuthGuard]},
  {path:'confirmorder',component:ConfirmOrderComponent},
  {path:'wishlist', component:WishlistComponent,canActivate:[AuthGuard]},
  {path:'cart', component:ShowCartComponent,canActivate:[AuthGuard]},
  {path:'order', component:ShowOrdersComponent,canActivate:[AuthGuard]},
  {path:'profile', component:ProfileComponent,canActivate:[AuthGuard]},
  {path:'home', component:HomeComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

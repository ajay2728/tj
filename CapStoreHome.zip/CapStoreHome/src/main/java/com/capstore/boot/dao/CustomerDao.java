package com.capstore.boot.dao;





import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capstore.boot.model.Customer;

@Repository("customerDao")
public interface CustomerDao extends JpaRepository<Customer, Integer>{

	Customer findByemailId(String emailId);
	

	/// method to get customer object for login validation
	
	  @Query("SELECT c FROM Customer c WHERE c.emailId=:emailId and c.password=:password")
	  Customer validateLogin(String emailId,String password);


	Customer findByCustomerId(int customerId);
	 
	
	
	//Customer findByEmailIdAndPassword(String email);
}


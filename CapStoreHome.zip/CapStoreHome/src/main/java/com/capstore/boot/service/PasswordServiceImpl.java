package com.capstore.boot.service;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.CustomerDao;
import com.capstore.boot.dao.IPasswordDao;
import com.capstore.boot.dao.MerchantDao;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Merchant;

@Service("passwordService")
public class PasswordServiceImpl implements IPasswordService {

	@Autowired
	CustomerDao customerDao;

	@Autowired
	MerchantDao merchantDao;

	@Override
	public Customer changecustomerPassword(Customer c, String password) {

		String pass = encrypt(password);

		c.setPassword(pass);

		customerDao.save(c);

		return c;
	}

	@Override
	public Merchant changemerchantPassword(Merchant merchant, String password) {

		String pass = encrypt(password);

		merchant.setPassword(pass);

		merchantDao.save(merchant);

		return merchant;
	}

	public String encrypt(String str) {
		// Getting encoder
		Base64.Encoder encoder = Base64.getEncoder();
		// encrypted String
		String ecode = encoder.encodeToString(str.getBytes());
		return ecode;
	}

}

package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Brand;
import com.capstore.boot.model.Category;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;



public interface InventoryService {

	public Inventory saveInventory(Inventory product);
    public void delete(Integer productId) ;
    
    public List<Inventory> getInventoryByName(String inventoryName);
    
    public List<Inventory> getAll();
	List<Inventory> getAllInventory();
	public List<Brand> getAllBrands();
	public List<Category> getAllCategories();
	public Inventory getProductByid(int pid);
	
	
	
	
}

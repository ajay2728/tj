package com.capstore.boot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.boot.model.ManagingCart;

public interface ManagingCartDao extends JpaRepository<ManagingCart, Integer> {

	
}

package com.capstore.boot.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Component
@Table(name="capWishList")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class WishList implements Serializable{

	@Id
	@GeneratedValue(generator="cust1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="cust1",sequenceName="capWishListseq",initialValue=1,allocationSize=1)
	private int wishId;
	
	@ManyToOne(fetch=FetchType.LAZY)	
	@JoinColumn(name="customerId")
	private Customer customer;
	
	@ManyToOne(fetch=FetchType.LAZY)	
	@JoinColumn(name="productId")
	private Inventory inventory;
	
//	private boolean isActive;
	
	
	public WishList(int wishId, Customer customer, Inventory inventory/*, boolean isActive*/) {
		super();
		this.wishId = wishId;
		this.customer = customer;
		this.inventory = inventory;
//		this.isActive = isActive;
	}

	public WishList() {
		System.out.println("wishlist");
	}

 /*public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}*/

	public Inventory getInventory() {
		return inventory;
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}

	public int getWishId() {
		return wishId;
	}

	public void setWishId(int wishId) {
		this.wishId = wishId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	
	
}

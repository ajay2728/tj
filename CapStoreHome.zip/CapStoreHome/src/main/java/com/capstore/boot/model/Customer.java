package com.capstore.boot.model;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

@Entity
@Component
@Table(name = "capcustomer")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})

public class Customer implements Serializable {

	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="cust1")
	@SequenceGenerator(name="cust1",sequenceName="capCustomerseq",initialValue=1,allocationSize=1)
	private int customerId;
	private String customerName;
	private String phoneNumber;
	@Column(unique=true)
	private String emailId;
	private String dateOfBirth;
	private String password;
	
	@OneToMany(targetEntity = Address.class, mappedBy = "customer",cascade = CascadeType.ALL)
	private List<Address> address;
	
	private String lastLogin;
	private String isActive;
	
	@OneToMany(targetEntity = Shipping.class, mappedBy = "customer")
	private List<Shipping> shipping;
	
	@OneToMany(targetEntity = BankAccount.class, mappedBy = "customer")
	private List<BankAccount> bank;
	
	
	@JsonIgnore
	@OneToMany(targetEntity = ManagingCart.class, mappedBy = "customer",cascade = CascadeType.ALL)
	private List<ManagingCart> managingCart;
	
	@JsonIgnore
	@OneToMany(targetEntity = Order.class, mappedBy = "customer",cascade = CascadeType.ALL)
	private List<Order> order;
	
	@OneToMany(targetEntity = FeedBack.class, mappedBy = "customer")
	private List<FeedBack> feedBack;
	
	@OneToMany(targetEntity = ReturnOrders.class, mappedBy = "customer")
	private List<ReturnOrders> returnOrders; 

	@JsonIgnore
	@OneToMany(targetEntity = WishList.class, mappedBy = "customer")
	private List<WishList> wishList;
	
	
	

	public Customer() {
		super();
	}



	public Customer(int customerId, String customerName, String phoneNumber, String emailId, String dateOfBirth,
			String password, List<Address> address, String lastLogin, String isActive, List<Shipping> shipping,
			List<BankAccount> bank, List<ManagingCart> managingCart, List<Order> order, List<FeedBack> feedBack,
			List<ReturnOrders> returnOrders, List<WishList> wishList) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
		this.address = address;
		this.lastLogin = lastLogin;
		this.isActive = isActive;
		this.shipping = shipping;
		this.bank = bank;
		this.managingCart = managingCart;
		this.order = order;
		this.feedBack = feedBack;
		this.returnOrders = returnOrders;
		this.wishList = wishList;
	}



	public List<ReturnOrders> getReturnOrders() {
		return returnOrders;
	}



	public void setReturnOrders(List<ReturnOrders> returnOrders) {
		this.returnOrders = returnOrders;
	}



	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	public String getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public List<Shipping> getShipping() {
		return shipping;
	}

	public void setShipping(List<Shipping> shipping) {
		this.shipping = shipping;
	}

	public List<BankAccount> getBank() {
		return bank;
	}

	public void setBank(List<BankAccount> bank) {
		this.bank = bank;
	}

	public List<ManagingCart> getManagingCart() {
		return managingCart;
	}

	public void setManagingCart(List<ManagingCart> managingCart) {
		this.managingCart = managingCart;
	}

	public List<Order> getOrder() {
		return order;
	}

	public void setOrder(List<Order> order) {
		this.order = order;
	}

	public List<FeedBack> getFeedBack() {
		return feedBack;
	}

	public void setFeedBack(List<FeedBack> feedBack) {
		this.feedBack = feedBack;
	}

	public List<WishList> getWishList() {
		return wishList;
	}

	public void setWishList(List<WishList> wishList) {
		this.wishList = wishList;
	}



	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", phoneNumber=" + phoneNumber
				+ ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth + ", password=" + password + ", address="
				+ address + ", lastLogin=" + lastLogin + ", isActive=" + isActive + ", shipping=" + shipping + ", bank="
				+ bank + ", managingCart=" + managingCart + ", order=" + order + ", feedBack=" + feedBack
				+ ", returnOrders=" + returnOrders + ", wishList=" + wishList + "]";
	}

	
	
	

}

package com.capstore.boot.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Component
@Table(name="capReturnOrders")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ReturnOrders implements Serializable{
	@Id
	@GeneratedValue(generator="cust1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="cust1",sequenceName="capReturnOrderseq",initialValue=1,allocationSize=1)
	private int returnId;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="orderId")
	private Order order;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="customerId")
	private Customer customer;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="transactionId")
	private Transaction transaction;
	
	private String description;
	private String returnMode;
	private Date returnDate;
	private String merchantValidation;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="merchantId")
	private Merchant merchant;
	
	@OneToOne(targetEntity = RefundMoney.class, mappedBy = "returnOrder")
	private RefundMoney refundMoney;
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	
	
	
	public RefundMoney getRefundMoney() {
		return refundMoney;
	}
	public void setRefundMoney(RefundMoney refundMoney) {
		this.refundMoney = refundMoney;
	}
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public int getReturnId() {
		return returnId;
	}
	public void setReturnId(int returnId) {
		this.returnId = returnId;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getReturnMode() {
		return returnMode;
	}
	public void setReturnMode(String returnMode) {
		this.returnMode = returnMode;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	
	public String getMerchantValidation() {
		return merchantValidation;
	}
	public void setMerchantValidation(String merchantValidation) {
		this.merchantValidation = merchantValidation;
	}
	public ReturnOrders() {
		super();
		System.out.println("return order");
	}
	public ReturnOrders(int returnId, Order order, Customer customer, Transaction transaction, String description,
			String returnMode, Date returnDate, String merchantValidation, Merchant merchant,
			RefundMoney refundMoney) {
		super();
		this.returnId = returnId;
		this.order = order;
		this.customer = customer;
		this.transaction = transaction;
		this.description = description;
		this.returnMode = returnMode;
		this.returnDate = returnDate;
		this.merchantValidation = merchantValidation;
		this.merchant = merchant;
		this.refundMoney = refundMoney;
	}
	
	

	
	
}

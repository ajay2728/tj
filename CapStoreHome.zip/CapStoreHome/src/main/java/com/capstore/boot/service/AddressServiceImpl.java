package com.capstore.boot.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.AddressDao;
import com.capstore.boot.model.Address;

@Service("addressService")
public class AddressServiceImpl implements IAddressService {

	@Autowired
    AddressDao addressDao;



	@Override
	public List<Address> getAllAddress() {
		return addressDao.findAll();
	}
	
	
}

package com.capstore.boot.service;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.boot.dao.MerchantDao;
import com.capstore.boot.model.Address;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;

@Service("merchantService")
public class MerchantServiceImpl implements MerchantService {
	
	@Autowired
    private MerchantDao merchantDao;
	
	@Override
	public List<Merchant> getAllMerchant() {
		return merchantDao.findAll();
	}

	@Override
	public  Merchant findMerchantById(Integer merchantId) {
		return merchantDao.getOne(merchantId);
	}

	@Override
	public boolean saveMerchant(Merchant merchant) {
		
		/*
		 * Merchant m = merchantDao.findByemailId(merchant.getEmailId()); if(m!=null) {
		 * merchant.setPassword(encrypt(merchant.getPassword()));
		 * merchantDao.save(merchant); return true; }else { return false; }
		 */
		boolean result=false;
		Merchant merchant2=merchantDao.save(merchant);
		if(merchant2!=null)
			result=true;
		return result;
	}

	@Override
	public void deleteMerchant(Integer merchantId) {
		merchantDao.deleteById(merchantId);
	}

	@Override
	public List<Merchant> getAllMerchant1() {
		return (List<Merchant>) merchantDao.findAllByActive();
	}

	@Override
	public Merchant findByMerchantEmail(String emailId) throws NullPointerException {
	
		Merchant m= merchantDao.findByemailId(emailId);
		if(m==null) {
			return m;
		}else {
		m.setPassword(decrypt(m.getPassword()));
		}
		return m;
	}

	public String encrypt(String str) {
		// Getting encoder
		Base64.Encoder encoder = Base64.getEncoder();

		//encrypted String
		String ecode = encoder.encodeToString(str.getBytes());
		return ecode;
	}
	
	public String decrypt(String str) {
		// Getting encoder
		Base64.Decoder decoder = Base64.getDecoder();

		//encrypted String
		byte[] ecode = decoder.decode(str);
		return new String(ecode);
	}

	@Override
	public List<Inventory> findBymerchantId(int id) {
		
		return merchantDao.findBymerchantId(id);
	}

	@Override
	public Merchant validateMerchant(String email) {
		return merchantDao.findByemailId(email);
	}

	@Transactional
	@Override
	public Merchant updateMerchant(Merchant merchant) {
		
		return merchantDao.save(merchant);
	}

	@Override
	public List<Merchant> getMerchantByStatus(String status) {
		return merchantDao.findByStatus(status);
	}

	@Override
	public List<Address> createAddress(Address address, Integer merchantid) {
		Merchant merchant = merchantDao.findById(merchantid).get();
		List<Address> merchantAddress = new ArrayList<Address>();
		merchantAddress = merchant.getAddress();
		address.setMerchant(merchant);
		merchantAddress.add(address);
		merchant.setAddress(merchantAddress);
		Merchant cu=merchantDao.save(merchant);
		System.out.println(merchant);
		System.out.println(cu);
		return merchantAddress;
	}

	


}

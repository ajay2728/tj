package com.capstore.boot.dao;

import java.util.List;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;



@Repository("merchantDao")

public interface MerchantDao extends JpaRepository<Merchant, Integer>{
	
	@Query("SELECT m FROM Merchant m WHERE m.isActive='false' ORDER BY m.merchantId")
	public List<Merchant> findAllByActive();

	public Merchant findByemailId(String emailId);

	public List<Inventory> findBymerchantId(int id);

	public List<Merchant> findByStatus(String status);

	//public Merchant findByEmailIdAndPassword(String email);
	
}

package com.capstore.boot.restcontroller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.boot.dao.IOrderDao;
import com.capstore.boot.dao.InventoryDao;
import com.capstore.boot.dao.ManagingCartDao;
import com.capstore.boot.model.Address;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.FeedBack;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.ManagingCart;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.model.Order;
import com.capstore.boot.model.Transaction;
import com.capstore.boot.model.WishList;
import com.capstore.boot.service.CustomerService;
import com.capstore.boot.service.IFeedbackService;
import com.capstore.boot.service.InventoryService;
import com.capstore.boot.service.MerchInventoryService;
import com.capstore.boot.service.MerchantService;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	CustomerService customerService;
	@Autowired
	InventoryService inventoryService;
	@Autowired
	MerchInventoryService merchInventoryService;
	@Autowired
	ManagingCartDao managingCartDao;
	@Autowired
	InventoryDao inventoryDao;
	@Autowired
	MerchantService merchantService;
	@Autowired
	IFeedbackService iFeedbackService;
	@Autowired
	IOrderDao iorderdao;

	@PostMapping("/addcustomer")
	public boolean addCustomer(@RequestBody Customer customer) {
	

		return customerService.createcustomer(customer);
	}

	@GetMapping("/logincustomer/{id}")
	public Customer validateCustomer(@PathVariable String id) {
		Customer customer = customerService.findCustomerByEmailId(id);
		/*
		 * String encryptedPassword = customer.getPassword(); String decryptedPassword =
		 * customerService.decrypt(encryptedPassword);
		 * customer.setPassword(decryptedPassword);
		 */
		return customer;
	}

	@PostMapping("/addaddress/{customerId}")
	public void addAddress(@PathVariable Integer customerId, @RequestBody Address address) {

		customerService.createAddress(address, customerId);
	}

	@GetMapping("/showproducts")
	public Set<Inventory> showProducts() {

		/*
		 * System.out.println("show products "+merchInventoryService.getAllInventory());
		 * return merchInventoryService.getAllInventory();
		 */

		List<Merchant> merchants = merchantService.getAllMerchant();
		List<Inventory> inventories = new ArrayList<Inventory>();
		for (Merchant merchant : merchants) {
			inventories.addAll(merchant.getInventory());
		}
		Set<Inventory> setInventories = new HashSet<Inventory>(inventories);
		return setInventories;
	}

	@PostMapping("/addtocart/{productId}/{custemailId}/{quantity}")
	public ManagingCart addToCart(@PathVariable Integer productId, @PathVariable String custemailId,
			@PathVariable Integer quantity) {

		Customer customer = customerService.findCustomerByEmailId(custemailId);
		Inventory inventory = inventoryService.getProductByid(productId);
		System.out.println(inventory);
		if (inventory.getQuantity() > quantity) {

			inventory.setQuantity(inventory.getQuantity() - quantity);
			ManagingCart managingCart = new ManagingCart();

			Inventory i = inventoryService.saveInventory(inventory);

			managingCart.setCustomer(customer);
			managingCart.setInventory(inventory);
			managingCart.setQuantity(quantity);
			managingCart.setStatus("active");
			List<ManagingCart> managingCarts = new ArrayList<ManagingCart>();

			if (customer.getManagingCart() != null)
				managingCarts = customer.getManagingCart();
			System.out.println("i am here");
			System.out.println(customer);
			managingCarts.add(managingCart);
			customer.setManagingCart(managingCarts);
			customerService.createcustomer(customer);

			return customerService.addToCart(managingCart);

		} else
			return null;

	}

	@PostMapping("/addtowishlist/{productId}/{custemailId}")
	public WishList addToWishlist(@PathVariable Integer productId, @PathVariable String custemailId) {

		Customer customer = customerService.findCustomerByEmailId(custemailId);
		Inventory inventory = inventoryService.getProductByid(productId);

		WishList wishList = new WishList();

		inventoryService.saveInventory(inventory);

		wishList.setCustomer(customer);
		wishList.setInventory(inventory);

		List<WishList> wishLists = new ArrayList<WishList>();
		if (customer.getWishList() != null)
			wishLists = customer.getWishList();

		wishLists.add(wishList);
		customer.setWishList(wishLists);

		return customerService.addToWishList(wishList);

	}

	@GetMapping("/showcartproducts/{customeremail}")
	public List<Inventory> showCartProducts(@PathVariable String customeremail) {
		Customer customer = customerService.findByEmailId(customeremail);

		List<ManagingCart> managingCart = customer.getManagingCart();
		List<Inventory> inventoriesdb = inventoryService.getAllInventory();
		List<Inventory> inventories = new ArrayList<Inventory>();
		for (ManagingCart m : managingCart) {
			if (inventoriesdb.contains(m.getInventory())) {
				Inventory inventory = m.getInventory();
				int quantity = m.getQuantity();
				double price = inventory.getPrice() * quantity;
				inventory.setPrice(price);
				inventories.add(inventory);
			}
		}

		return inventories;
	}

	@GetMapping("/showwishlist/{customeremail}")
	public List<Inventory> showWishlist(@PathVariable String customeremail) {
		Customer customer = customerService.findByEmailId(customeremail);

		List<WishList> wishlist = customer.getWishList();
		List<Inventory> inventoriesdb = inventoryService.getAllInventory();
		List<Inventory> inventories = new ArrayList<Inventory>();
		for (WishList w : wishlist) {
			if (inventoriesdb.contains(w.getInventory())) {
				Inventory inventory = w.getInventory();

				inventories.add(inventory);
			}
		}

		return inventories;
	}

	@GetMapping("/showproductsbycategory/{categoryname}")
	public List<Inventory> showProducts(@PathVariable String categoryname) {

		List<Inventory> allInventories = merchInventoryService.getAllInventory();

		List<Inventory> sortedInventories = new ArrayList<Inventory>();

		for (Inventory i : allInventories) {
			if (i.getCategory().getCategoryName().equals(categoryname))
				sortedInventories.add(i);
		}

		return sortedInventories;
	}

	@PutMapping("/updatecustomer/{custid}")
	public Customer updateCustomer(@RequestBody Customer customer, @PathVariable Integer custid) {
		// Customer updateCustomer=customerService.findOne(custmailid);
		customer.setCustomerId(custid);
		return customerService.updatecustomer(customer);
	}

	@GetMapping("/customerprofile/{customeremail}")
	public Customer showCustomerById(@PathVariable String customeremail) {
		return customerService.findByEmailId(customeremail);
	}

	@PostMapping("/addfeedback/{customerid}/{productid}")
	public FeedBack addFeedback(@RequestBody FeedBack feedback, @PathVariable Integer customerid,

			@PathVariable Integer productid) {
		Inventory inventory = inventoryService.getProductByid(productid);
		Customer customer = customerService.findOne(customerid);
		Merchant merchant = inventory.getMerchant();

		List<FeedBack> productFeedback = inventory.getFeedback();
		if (productFeedback == null)
			productFeedback = new ArrayList<FeedBack>();
		productFeedback.add(feedback);

		List<FeedBack> productCustomerFeedback = customer.getFeedBack();
		if (productCustomerFeedback == null)
			productCustomerFeedback = new ArrayList<FeedBack>();
		productCustomerFeedback.add(feedback);

		inventory.setFeedback(productFeedback);
		List<Inventory> inventories = merchant.getInventory();
		inventories.add(inventory);
		merchant.setInventory(inventories);
		customer.setFeedBack(productCustomerFeedback);
		feedback.setInventory(inventory);
		feedback.setMerchant(merchant);
		feedback.setCustomer(customer);
		return iFeedbackService.createFeedback(feedback);
	}

	@PostMapping("/placeorder/{customerid}/{productid}")
	public Order placeOrder(@PathVariable Integer customerid, @PathVariable Integer productid) {
		Customer customer = customerService.findOne(customerid);
		Order order = new Order();
		Date date = new Date();
		order.setOrderDate(date.toString());
		order.setDeliveredDate(date.toString());
		List<ManagingCart> managingCarts = customer.getManagingCart();
		List<ManagingCart> listManagingCart = new ArrayList<ManagingCart>();

		for (ManagingCart m : managingCarts) {
			if (m.getInventory().getProductId() == productid) {
				listManagingCart.add(m);
				managingCarts.remove(m);
				break;
			}
		}

		order.setManagingCart(listManagingCart);
		customer.setManagingCart(managingCarts);
		order.setCustomer(customer);

		List<Order> orderList = new ArrayList<Order>();

		if (customer.getOrder() != null)
			orderList = customer.getOrder();

		orderList.add(order);

		customer.setOrder(orderList);

		customerService.createcustomer(customer);
		return iorderdao.save(order);
	}

	@GetMapping("/showorders/{customeremail}")
	public List<ManagingCart> showOrders(@PathVariable String customeremail) {
		Customer customer = customerService.findByEmailId(customeremail);
		List<Order> orders = customer.getOrder();
		List<ManagingCart> carts = new ArrayList<ManagingCart>();
		for (Order order : orders) {
			if (order.getDeliveryStatus().equals("active")) {
				carts.addAll(order.getManagingCart());

			}
		}
		return carts;
	}

	@PostMapping("/changepassword/{customerid}/{newpassword}/{confirmpassword}")
	public Customer changePassword(@PathVariable Integer customerid, @PathVariable String newpassword,
			@PathVariable String confirmpassword) {
		Customer customer = customerService.findOne(customerid);
		String oldpassword = customer.getPassword();
		Customer updatedcustomer = customer;
		if (newpassword.equals(confirmpassword)) {
			if (oldpassword.equals(newpassword)) {
			} else {
				customer.setPassword(newpassword);
				updatedcustomer = customerService.updatecustomer(customer);
			}
		}
		return updatedcustomer;

	}

	/*
	 * @GetMapping("/customertransaction/customerid") public Transaction
	 * transactions(@PathVariable Integer customerid,@RequestBody Transaction
	 * transaction) {
	 * 
	 * return null; }
	 */
}

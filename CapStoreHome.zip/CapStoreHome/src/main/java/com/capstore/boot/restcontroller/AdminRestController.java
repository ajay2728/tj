package com.capstore.boot.restcontroller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.boot.dao.CouponDao;
import com.capstore.boot.model.Admin;
import com.capstore.boot.model.Coupons;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.AdminService;
import com.capstore.boot.service.CustomerService;
import com.capstore.boot.service.InventoryService;
import com.capstore.boot.service.MerchInventoryService;
import com.capstore.boot.service.MerchantService;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/admin")
public class AdminRestController {

	@Autowired
	AdminService adminService;

	@Autowired
	CustomerService customerService;
	@Autowired
	MerchantService merchantService;
	@Autowired
	MerchInventoryService merchInventoryService;
	@Autowired
	InventoryService inventoryService;
	@Autowired
	CouponDao couponDao;

	@GetMapping("/loginadmin/{id}")
	public Admin validateAdmin(@PathVariable Integer id) {
		
		return adminService.validateAdmin(id);
	}

	@GetMapping("/showcustomers")
	public List<Customer> showCustomers() {
		return customerService.getAllCustomer();
	}

	@GetMapping("/showmerchants")
	public List<Merchant> showMerchants() {
		return merchantService.getAllMerchant();
	}

	@GetMapping("/showmerchantstatus/{status}")
	public List<Merchant> showMerchantstatus(@PathVariable String status) {

		return merchantService.getMerchantByStatus(status);
	}

	@GetMapping("/showproducts")
	public Set<Inventory> showProducts() {
		List<Merchant> merchants = merchantService.getAllMerchant();
		List<Inventory> inventories = new ArrayList<Inventory>();
		for (Merchant merchant : merchants) {
			inventories.addAll(merchant.getInventory());
		}
		Set<Inventory> setInventories = new HashSet<Inventory>(inventories);
		return setInventories;
	}

	@GetMapping("/showmerchantproducts/{merchantid}")
	public List<Inventory> showProducts(@PathVariable Integer merchantid) {
		return merchInventoryService.getMerchantInventory(merchantid);
	}

	@PostMapping("/createcoupon/{categoryname}")
	public Coupons createCoupon(@RequestBody Coupons coupon, @PathVariable String categoryname) {
		List<Inventory> allInventories = merchInventoryService.getAllInventory();

		List<Inventory> sortedInventories = new ArrayList<Inventory>();

		for (Inventory i : allInventories) {
			if (i.getCategory().getCategoryName().equals(categoryname))
				sortedInventories.add(i);
		}
		Coupons coupons=new Coupons();
		for (Inventory inventory : sortedInventories) {
			
			coupons=coupon;
			inventory.setCoupon(coupons);
			coupons.setInventory(inventory);
			adminService.createCoupon(coupons);
			
		}
		return coupons;
	}
	
	@GetMapping("/showcoupon/{couponcode}")
	public double showCoupon(@PathVariable String couponcode) {
		Coupons coupons=couponDao.findByCouponCode(couponcode);
		double amount=coupons.getCouponAmount();
		return amount;
	}
	
	@GetMapping("/customersearch/{custid}")
	public Customer getCustomer(@PathVariable Integer custid) {
		return customerService.findOne(custid);
	}

	@GetMapping("/merchantsearch/{merchantid}")
	public Merchant getMerchant(@PathVariable Integer merchantid) {
		return merchantService.findMerchantById(merchantid);
	}

}

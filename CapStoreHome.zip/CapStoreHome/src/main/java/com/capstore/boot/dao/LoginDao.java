package com.capstore.boot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstore.boot.model.Customer;

@Repository("loginDao")

public interface LoginDao extends JpaRepository<Customer, Integer> {

	@Query("update Customer c set c.password=:newPassword where c.customerId=:customerId")
	void updatePassword(@Param("newPassword") String newPassword, @Param("customerId") int customerId);

	@Query("SELECT c FROM Customer c WHERE c.emailId=:emailId")
	Customer getOneByEmail(@Param("emailId") String emailId);

}

package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Merchant;



public interface IPasswordService {


	Customer changecustomerPassword(Customer c, String password);

	Merchant changemerchantPassword(Merchant m, String password);
}
